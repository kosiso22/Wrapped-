// script.js
function register() {
    alert("Register button clicked!");
}

// Add more interactivity as needed
